#include <pebble.h>
#include "cl_progressbar.h"

enum {
  KEY_TEXT,
  KEY_BAT,
};
Window *window;
TextLayer *text_layer;
ActionBarLayer *action_bar;
GBitmap *pause_resume_icon;
ProgressBarLayer *pb_layer;

#define MARGIN 3
#define WIDTH 118

char *translate_error(AppMessageResult result) {
  switch (result) {
    case APP_MSG_OK: return "APP_MSG_OK";
    case APP_MSG_SEND_TIMEOUT: return "APP_MSG_SEND_TIMEOUT";
    case APP_MSG_SEND_REJECTED: return "APP_MSG_SEND_REJECTED";
    case APP_MSG_NOT_CONNECTED: return "APP_MSG_NOT_CONNECTED";
    case APP_MSG_APP_NOT_RUNNING: return "APP_MSG_APP_NOT_RUNNING";
    case APP_MSG_INVALID_ARGS: return "APP_MSG_INVALID_ARGS";
    case APP_MSG_BUSY: return "APP_MSG_BUSY";
    case APP_MSG_BUFFER_OVERFLOW: return "APP_MSG_BUFFER_OVERFLOW";
    case APP_MSG_ALREADY_RELEASED: return "APP_MSG_ALREADY_RELEASED";
    case APP_MSG_CALLBACK_ALREADY_REGISTERED: return "APP_MSG_CALLBACK_ALREADY_REGISTERED";
    case APP_MSG_CALLBACK_NOT_REGISTERED: return "APP_MSG_CALLBACK_NOT_REGISTERED";
    case APP_MSG_OUT_OF_MEMORY: return "APP_MSG_OUT_OF_MEMORY";
    case APP_MSG_CLOSED: return "APP_MSG_CLOSED";
    case APP_MSG_INTERNAL_ERROR: return "APP_MSG_INTERNAL_ERROR";
    default: return "UNKNOWN ERROR";
  }
}

void select_click_handler(ClickRecognizerRef recognizer, void *context) {
   DictionaryIterator *iterator;
	 app_message_outbox_begin(&iterator);
	 dict_write_uint8(iterator, 1, 0);
	 app_message_outbox_send();
  
   // Set values for debug
   // progressbar_layer_set_progress(pb_layer, 75);
   // text_layer_set_text(text_layer, "08m34s\n387m\n96 kcal\n115");
 }

 void click_config_provider(void *context) {
   window_single_click_subscribe(BUTTON_ID_SELECT, select_click_handler);
 }

void in_received_handler(DictionaryIterator *received, void *context) {
  Tuple *text_tuple = dict_find(received, KEY_TEXT);
  if (text_tuple) {
    text_layer_set_text(text_layer, text_tuple->value->cstring);
  }
  Tuple *bat_tuple = dict_find(received, KEY_BAT);
  if (bat_tuple) {
    progressbar_layer_set_progress(pb_layer, bat_tuple->value->uint8);
  }
}

void in_dropped_handler(AppMessageResult reason, void *context) {
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Incoming message dropped: %i - %s", reason, translate_error(reason));
}

void handle_init(void) {
  app_message_register_inbox_received(in_received_handler);
  app_message_register_inbox_dropped(in_dropped_handler);
  
  const uint32_t inbound_size = 128;
  const uint32_t outbound_size = 10;
  app_message_open(inbound_size, outbound_size);
  
	// Create a window and text layer
	window = window_create();
	text_layer = text_layer_create(GRect(MARGIN, MARGIN, WIDTH, 116));
	
	// Set the text, font, and text alignment
	text_layer_set_text(text_layer, "Start workout in Endomondo app");
	text_layer_set_font(text_layer, fonts_get_system_font(FONT_KEY_GOTHIC_28_BOLD));
	text_layer_set_text_alignment(text_layer, GTextAlignmentCenter);
	
	// Add the text layer to the window
	layer_add_child(window_get_root_layer(window), text_layer_get_layer(text_layer));

	// Push the window
	window_stack_push(window, true);
  
  // Initialize the action bar:
  action_bar = action_bar_layer_create();
  // Associate the action bar with the window:
  action_bar_layer_add_to_window(action_bar, window);
  // Set the click config provider:
  action_bar_layer_set_click_config_provider(action_bar,
                                             click_config_provider);
  // Set the icons:
  pause_resume_icon = gbitmap_create_with_resource(RESOURCE_ID_IMAGE_PAUSE_RESUME);
  action_bar_layer_set_icon(action_bar, BUTTON_ID_SELECT, pause_resume_icon);
  
  // Add the progressbar with text
  TextLayer *bat_text_layer = text_layer_create(GRect(MARGIN, 120, WIDTH, 16));
  text_layer_set_text(bat_text_layer, "Phone battery level");
  text_layer_set_font(bat_text_layer, fonts_get_system_font(FONT_KEY_GOTHIC_14));
	text_layer_set_text_alignment(bat_text_layer, GTextAlignmentLeft);
  layer_add_child(window_get_root_layer(window), text_layer_get_layer(bat_text_layer));
  pb_layer = progressbar_layer_create(GRect(MARGIN, 136, WIDTH, 13));
  layer_add_child(window_get_root_layer(window), progressbar_layer_get_layer(pb_layer));
}

void handle_deinit(void) {
	// Destroy the text layer
	text_layer_destroy(text_layer);
  // Destroy the progressbar
  progressbar_layer_destroy(pb_layer);  
	// Destroy the window
	window_destroy(window);
}

int main(void) {
	handle_init();
	app_event_loop();
	handle_deinit();
}
